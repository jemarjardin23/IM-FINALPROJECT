<title>Sign Up </title>
<?php
      include 'views/header.php';
    ?>
<form id ="signinform" action="models/signup-user.php" method="POST">
    <label for="uname">Username</label>
    <input type="text" id="uname" name="uname" placeholder="Username" required>
    <label for="email">Email</label
    <input type="text" id="email" name="email" placeholder="Email" required>
    <label for="fname">First name</label>
    <input type="text" id="fname" name="fname" placeholder="First Name" required>
    <label for="lname">Last name</label>
    <input type="text" id="lname" name="lname" placeholder="Last Name" required>
    <label for="gender">Gender</label>
    <select id="gender" name="gender">
        <option value="male">Male</option>
        <option value="Female">Female</option>
    </select>
    <label for="bdate">Last Name</label>
    <input type="date" id="bdate" name="bdate" required>
    <label for="pass">Password</label>
    <input type="password" id="pass" name="pass" placeholder="Password" required>
    <label for="cpass">Confirm Password</label>
    <input type="password" id="cpass" name="cpass" placeholder= "Confirm Password" required>
    
    
    <div id="signinup">
        <input type="checkbox" id="signedup" name="signup" value="signedin">
        <label for="signedin">I have read. EULA</label>
        
    </div>  
    <input type="submit" value="signin">
    
</form>    


 <?php
       
       include 'views/footer.php';
        ?>

  