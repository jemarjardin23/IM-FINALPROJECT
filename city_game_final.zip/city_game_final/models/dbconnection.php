<?php

function create_connection(){
    $host="localhost";
    $username="root";
    $password="";
    $database="socmed_vera_b";
    
    
    return new mysqli($host,$username,$password,$database);
    
    
}