 <?php
include 'views/header.php';

echo "GALLERY";
?><section class="gallery-section">
  <h2>Sports Pictures</h2>

  <div class="gallery-grid">
    <div class="gallery-item football">
      <img src="image/foot.jpg" alt="Football">
      <div class="caption">Football</div>
    </div>
    <div class="gallery-item basketball">
      <img src="image/basket.jpg" alt="Basketball">
      <div class="caption">Basketball</div>
    </div>
    <div class="gallery-item tennis">
      <img src="image/tennis.avif" alt="Tennis">
      <div class="caption">Tennis</div>
    </div>
    <div class="gallery-item cricket">
      <img src="image/cricket.webp" alt="Cricket">
      <div class="caption">Cricket</div>
    </div>
  </div>
  <div class="gallery-grid">
    <div class="gallery-item volleyball">
      <img src="image/uu.jpeg" alt="Volleyball">
      <div class="caption">Volleyball</div>
    </div>
    <div class="gallery-item baseball">
      <img src="image/ii.jpg" alt="Baseball">
      <div class="caption">Baseball</div>
    </div>
    <div class="gallery-item boxing">
      <img src="image/bb.webp" alt="Boxing">
      <div class="caption">Boxing</div>
    </div>
    <div class="gallery-item swimming">
      <img src="image/ss.jpg" alt="Swimming">
      <div class="caption">Swimming</div>
    </div>
  </div>
  
</section>




  