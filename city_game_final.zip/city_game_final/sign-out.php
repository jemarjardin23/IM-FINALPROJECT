 <?php
include 'views/header.php';

echo "Sign out";



include 'views/footer.php';
?>
  