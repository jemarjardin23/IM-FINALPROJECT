<title>Sign In Your Account</title> 
<?php
include 'views/header.php';
?>
<form id="signinform" action="models/signin-user.php" method="POST">
    <label for="uname">Username or Email</label>
    <input type="text" id="uname" name="uname" placeholder="Username or Email" required>
    <label for="pass">Password</label>
    <input type="text" id="pass" name="pass" placeholder="Password" required>
    <div id="signedinbox">
        <input type="checkbox" id="signedin" name="signedin"  value="signedin">
        <label for="signedin">Keep me signed in.</label>
        
        
       </div>
    <input type="submit" value="signin">
</form>
         


<?php
include 'views/footer.php';

  