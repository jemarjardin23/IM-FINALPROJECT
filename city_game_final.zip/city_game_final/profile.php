 <?php
include 'views/header.php';

echo "PROFILE";



include 'views/footer.php';
?>
  