 <?php
include 'views/header.php';

echo "ABOUT";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>About Sports</title>
  
    
  
</head>
<body>
  <section class="hero">
    <h1>SPORTS</h1>
    <h2>About Our Sports Hub</h2>
    <p>Welcome to our sports information center! Explore different sports, learn the basics, and discover what makes each game exciting.</p>
  </section>

  <section class="section">
    <div class="sport">
      <h3>⚽ Football</h3>
      <p>Football, also known as soccer in some countries, is a globally loved team sport where players aim to score goals by kicking a ball into the opponent's net.</p>
    </div>
    <div class="sport">
      <h3>🏀 Basketball</h3>
      <p>Basketball is a fast-paced game where two teams of five players each try to score points by throwing a ball through the opponent's hoop.</p>
    </div>
    <div class="sport">
      <h3>🎾 Tennis</h3>
      <p>Tennis is a racket sport played individually or in pairs, where players hit a ball over a net and aim to score points by making it unreturnable.</p>
    </div>
    <div class="sport">
      <h3>🏏 Cricket</h3>
      <p>Cricket is a bat-and-ball game played between two teams. It involves batting, bowling, and fielding, with the aim of scoring more runs than the opposition.</p>
    </div>
    <div class="sport">
      <h3>🥋 Martial Arts</h3>
      <p>Martial arts include a variety of combat practices like karate, taekwondo, and judo, which focus on discipline, self-defense, and physical fitness.</p>
    </div>
  </section>
</body>
</html>




include 'views/footer.php';
?>
  