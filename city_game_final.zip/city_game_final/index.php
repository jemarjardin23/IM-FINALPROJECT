 <?php
include 'views/header.php';

echo "HOME";

$sports = [
    ['name' => 'Football', 'image' => 'image/foot.jpg', 'players' => ['Lionel Messi', 'Cristiano Ronaldo']],
    ['name' => 'Basketball', 'image' => 'image/basket.jpg', 'players' => ['LeBron James', 'Stephen Curry']],
    ['name' => 'Tennis', 'image' => 'image/tennis.avif', 'players' => ['Roger Federer', 'Serena Williams']],
    ['name' => 'Cricket', 'image' => 'image/cricket.webp', 'players' => ['Virat Kohli', 'Ben Stokes']],
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>City Game</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="hero">
        <h1>Welcome to City Game</h1>
        <p>Your hub for latest updates on popular sports and players.</p>
    </header>

    <section class="sports-list">
        <h2>Popular Sports</h2>
        <div class="cards">
            <?php foreach ($sports as $sport): ?>
                <div class="card">
                    <img src="<?= $sport['image'] ?>" alt="<?= $sport['name'] ?>">
                    <h3><?= $sport['name'] ?></h3>
                    <p>Top Players:</p>
                    <ul>
                        <?php foreach ($sport['players'] as $player): ?>
                            <li><?= $player ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
        
    </section>
</body>
</html>


  